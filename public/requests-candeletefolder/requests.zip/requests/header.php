<!--<H2>Welcome To --><?php //echo $sitename; ?><!--</H2>-->
<meta property="fb:app_id" content="********" />
<meta property="og:type" content="website" />
<meta property="og:url" content="http://rc101.us/" />
<meta property="og:title" content="RC101 Your Rockin' Country Station" />
<meta property="og:description" content="Download & Stream Your Favorite Country Music!" />
<meta property="og:image" content="http://rc101.us/public/images/ogrc101.png" />

<div style="text-align:center;">
<!--<img src="jammin.jpg" alt="Jammin 92" class="responsive center" width="600" height="400" style=" margin-top: 20px; padding: 10px;">-->
</div>
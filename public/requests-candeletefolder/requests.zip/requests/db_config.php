<?php error_reporting(0); ?> 

<?php

/*
 * All database connection variables
 */

define('DB_USER', "dzm_jammin92_user"); // db user
define('DB_PASSWORD', "vFCLV2kb)30,"); // db password (mention your db password here)
define('DB_DATABASE', "dzm_jammin92"); // database name
define('DB_SERVER', "localhost");
// db server
?>